module.exports = {
    mongodb: {
        user: "mxt",
        pass: "1q2w3e4r!"
    }
};
